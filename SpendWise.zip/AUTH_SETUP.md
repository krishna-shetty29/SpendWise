# Firebase Authentication setup

SpendWise uses Firebase Authentication for account identity. Passwords are sent to Firebase Authentication for verification; the app does not save or log them. Expense and budget data remain in the app's existing local `SharedPreferences` store. This version does not upload financial records.

## Connect a Firebase project

1. Create or open a project in the [Firebase console](https://console.firebase.google.com/).
2. Add an Android app whose package name is `com.example.spendwise`.
3. In **Authentication → Sign-in method**, enable **Email/Password** and **Google**.
4. For Google sign-in, add the app's debug SHA-1 certificate fingerprint in **Project settings → Your apps**. For this development environment, the debug SHA-1 is `63:8F:DE:EC:F6:45:6F:3C:FC:31:69:FC:41:1F:05:EC:34:6E:72:89`. If you build on another computer or use a different signing key, run `:app:signingReport` from Android Studio's Gradle tool window and register that key's SHA-1 instead.
5. Download the resulting `google-services.json` and put it in this project's `app/` directory. Keep it local; this project ignores that file. The file contains Firebase app identifiers, not a service-account credential.
6. Sync Gradle and rebuild. The Google services plugin is applied when that file is present. The app's sign-in screen remains safely unavailable while it is absent, and local expense tracking continues to work.

No service-account JSON, private key, or server secret belongs in this Android app.
