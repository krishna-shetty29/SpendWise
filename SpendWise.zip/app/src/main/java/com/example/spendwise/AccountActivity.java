package com.example.spendwise;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.util.Patterns;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.content.ContextCompat;

import androidx.credentials.ClearCredentialStateRequest;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.ClearCredentialException;
import androidx.credentials.exceptions.GetCredentialCancellationException;
import androidx.credentials.exceptions.GetCredentialException;

import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseNetworkException;
import com.google.firebase.FirebaseTooManyRequestsException;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;

import java.util.concurrent.Executor;

public class AccountActivity extends AppCompatActivity {
    static final String EXTRA_FIRST_LAUNCH = "first_launch";
    private int green = Color.rgb(153, 83, 0);
    private int amberFill = Color.rgb(242, 177, 56);
    private int ink = Color.rgb(22, 37, 54);
    private int muted = Color.rgb(83, 101, 122);
    private int background = Color.rgb(244, 247, 251);
    private int surface = Color.rgb(232, 240, 249);
    private int soft = Color.rgb(218, 232, 246);
    private int buttonInk = Color.rgb(35, 38, 42);
    private FirebaseAuth auth;
    private CredentialManager credentialManager;
    private boolean configured;
    private boolean dark;
    private boolean creatingAccount;
    private boolean firstLaunch;
    private boolean showEmailForm;
    private FrameLayout root;
    private LinearLayout form;
    private EditText emailInput, passwordInput;
    private Button googleButton, emailButton, modeButton, signOutButton, deleteButton;
    private ProgressBar spinner;
    private TextView loadingText, errorText;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        firstLaunch = getIntent().getBooleanExtra(EXTRA_FIRST_LAUNCH, false);
        WindowCompat.enableEdgeToEdge(getWindow());
        dark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        if (dark) { green = Color.rgb(255, 190, 65); amberFill = Color.rgb(255, 190, 65); ink = Color.rgb(243, 246, 250); muted = Color.rgb(190, 202, 216); background = Color.rgb(18, 18, 18); surface = Color.rgb(29, 43, 59); soft = Color.rgb(39, 67, 96); }
        getWindow().setStatusBarColor(Color.TRANSPARENT); getWindow().setNavigationBarColor(Color.TRANSPARENT);
        getWindow().getDecorView().setSystemUiVisibility(dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        configured = !FirebaseApp.getApps(this).isEmpty();
        if (configured) { auth = FirebaseAuth.getInstance(); credentialManager = CredentialManager.create(this); }
        buildScreen();
    }

    private void buildScreen() {
        root = new FrameLayout(this); root.setBackgroundColor(background);
        ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> { Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars()); view.setPadding(bars.left, bars.top, bars.right, bars.bottom); return insets; });
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setClipToPadding(false);
        LinearLayout page = column(); page.setPadding(dp(24), dp(20), dp(24), dp(40)); scroll.addView(page);
        root.addView(scroll, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout header = row();
        if (firstLaunch && showEmailForm) {
            TextView back = text("‹", 30, ink, false); back.setGravity(Gravity.CENTER); header.addView(back, new LinearLayout.LayoutParams(dp(44), dp(48))); back.setOnClickListener(v -> { showEmailForm = false; buildScreen(); });
        } else if (!firstLaunch) {
            TextView back = text("‹", 30, ink, false); back.setGravity(Gravity.CENTER); header.addView(back, new LinearLayout.LayoutParams(dp(44), dp(48))); back.setOnClickListener(v -> finish());
        } else {
            ImageView logo = new ImageView(this); logo.setImageResource(R.drawable.ic_spendwise_mark); logo.setContentDescription("SpendWise logo");
            header.addView(logo, new LinearLayout.LayoutParams(dp(46), dp(46)));
        }
        header.addView(text(firstLaunch ? "Welcome to SpendWise" : "Account & privacy", firstLaunch ? 20 : 21, ink, true), new LinearLayout.LayoutParams(0, -2, 1)); page.addView(header);

        TextView intro = text(firstLaunch ? "Track spending clearly and stay in control of your money." : "Sign in securely, or keep using SpendWise on this device.", 14, muted, false); LinearLayout.LayoutParams introLp = new LinearLayout.LayoutParams(-1, -2); introLp.topMargin = dp(18); page.addView(intro, introLp);
        addPrivacyCard(page);

        FirebaseUser user = configured ? auth.getCurrentUser() : null;
        if (user != null) buildSignedIn(page, user);
        else if (!configured) buildNotConfigured(page);
        else if (firstLaunch && !showEmailForm) buildWelcomeChoices(page);
        else buildSignedOut(page);
        setContentView(root);
    }

    private void addPrivacyCard(LinearLayout page) {
        LinearLayout card = column(); card.setPadding(dp(16), dp(15), dp(16), dp(15)); card.setBackground(rounded(surface, 17));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(18); page.addView(card, lp);
        card.addView(text("Your expenses stay on this device", 15, ink, true));
        TextView detail = text("Signing in sends your email and account credentials to Firebase Authentication. SpendWise does not upload your expenses or budgets, and signing out will not remove them from this device.", 12, muted, false);
        detail.setLineSpacing(dp(3), 1f); LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(-1, -2); dlp.topMargin = dp(7); card.addView(detail, dlp);
    }

    private void buildWelcomeChoices(LinearLayout page) {
        LinearLayout card = column(); card.setPadding(dp(18), dp(18), dp(18), dp(18)); card.setBackground(rounded(surface, 18));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(20); page.addView(card, lp);
        card.addView(text("Choose how to continue", 17, ink, true));
        TextView detail = text("Your expenses stay on this device. Signing in does not upload or sync financial data.", 13, muted, false);
        detail.setLineSpacing(dp(3), 1f); LinearLayout.LayoutParams detailLp = new LinearLayout.LayoutParams(-1, -2); detailLp.topMargin = dp(6); card.addView(detail, detailLp);

        googleButton = button("Continue with Google", false); LinearLayout.LayoutParams googleLp = new LinearLayout.LayoutParams(-1, -2); googleLp.topMargin = dp(18); card.addView(googleButton, googleLp); googleButton.setOnClickListener(v -> beginGoogleFlow(false));
        Button create = button("Create an account", true); LinearLayout.LayoutParams createLp = new LinearLayout.LayoutParams(-1, -2); createLp.topMargin = dp(9); card.addView(create, createLp);
        create.setOnClickListener(v -> { creatingAccount = true; showEmailForm = true; buildScreen(); });
        Button guest = button("Continue without an account", false); LinearLayout.LayoutParams guestLp = new LinearLayout.LayoutParams(-1, -2); guestLp.topMargin = dp(9); page.addView(guest, guestLp);
        guest.setOnClickListener(v -> enterTracker("guest"));
        TextView signIn = text("Already have an account? Sign in", 14, dark ? Color.rgb(255, 190, 65) : Color.rgb(34, 83, 126), true);
        signIn.setGravity(Gravity.CENTER); signIn.setPadding(dp(12), dp(13), dp(12), dp(13)); signIn.setFocusable(true); signIn.setClickable(true);
        signIn.setOnClickListener(v -> { creatingAccount = false; showEmailForm = true; buildScreen(); });
        LinearLayout.LayoutParams signInLp = new LinearLayout.LayoutParams(-1, -2); signInLp.topMargin = dp(5); page.addView(signIn, signInLp);
    }

    private void buildNotConfigured(LinearLayout page) {
        LinearLayout card = column(); card.setPadding(dp(18), dp(18), dp(18), dp(18)); card.setBackground(rounded(surface, 18));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(20); page.addView(card, lp);
        card.addView(text("Account sign-in needs setup", 17, ink, true));
        TextView note = text("Account sign-in is unavailable until Firebase is configured. No credentials are collected, and local expense tracking remains available.", 13, muted, false);
        note.setLineSpacing(dp(3), 1f); LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(-1, -2); noteLp.topMargin = dp(8); card.addView(note, noteLp);
        Button google = button("Continue with Google", false); google.setEnabled(false); google.setAlpha(.55f);
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(-1, -2); btnLp.topMargin = dp(16); card.addView(google, btnLp);
        Button email = button("Create an account with email", false); email.setEnabled(false); email.setAlpha(.55f);
        LinearLayout.LayoutParams emailLp = new LinearLayout.LayoutParams(-1, -2); emailLp.topMargin = dp(8); card.addView(email, emailLp);
        TextView setup = text("Setup required: register com.example.spendwise in Firebase, enable Email/Password and Google providers, add the app's SHA-1 for Google sign-in, and place google-services.json in app/.", 11, muted, false);
        setup.setLineSpacing(dp(3), 1f); LinearLayout.LayoutParams setupLp = new LinearLayout.LayoutParams(-1, -2); setupLp.topMargin = dp(8); card.addView(setup, setupLp);
        Button local = button("Continue without an account", true); LinearLayout.LayoutParams localLp = new LinearLayout.LayoutParams(-1, -2); localLp.topMargin = dp(16); page.addView(local, localLp); local.setOnClickListener(v -> enterTracker("guest"));
    }

    private void buildSignedOut(LinearLayout page) {
        form = column(); form.setPadding(dp(18), dp(17), dp(18), dp(18)); form.setBackground(rounded(surface, 18)); LinearLayout.LayoutParams formLp = new LinearLayout.LayoutParams(-1, -2); formLp.topMargin = dp(20); page.addView(form, formLp);
        TextView heading = text(creatingAccount ? "Create your account" : (firstLaunch ? "Sign in to SpendWise" : "Sign in or create an account"), 18, ink, true); form.addView(heading);
        if (!firstLaunch || !showEmailForm) {
            googleButton = button("Continue with Google", false); LinearLayout.LayoutParams googleLp = new LinearLayout.LayoutParams(-1, -2); googleLp.topMargin = dp(15); form.addView(googleButton, googleLp); googleButton.setOnClickListener(v -> beginGoogleFlow(false));
            TextView separator = text("or continue with email", 12, muted, false); separator.setGravity(Gravity.CENTER); LinearLayout.LayoutParams sepLp = new LinearLayout.LayoutParams(-1, -2); sepLp.topMargin = dp(17); sepLp.bottomMargin = dp(8); form.addView(separator, sepLp);
        }
        emailInput = input("Email address", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        passwordInput = input("Password (at least 6 characters)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        passwordInput.setSaveEnabled(false);
        form.addView(emailInput); addGap(form, 5); form.addView(passwordInput);
        errorText = text("", 12, dark ? Color.rgb(255, 145, 135) : Color.rgb(176, 38, 36), false); errorText.setVisibility(View.GONE); LinearLayout.LayoutParams errorLp = new LinearLayout.LayoutParams(-1, -2); errorLp.topMargin = dp(8); form.addView(errorText, errorLp);
        emailButton = button(creatingAccount ? "Create account" : "Sign in", true); LinearLayout.LayoutParams actionLp = new LinearLayout.LayoutParams(-1, -2); actionLp.topMargin = dp(13); form.addView(emailButton, actionLp); emailButton.setOnClickListener(v -> submitEmail());
        modeButton = button(creatingAccount ? "I already have an account" : "Create an account", false); LinearLayout.LayoutParams modeLp = new LinearLayout.LayoutParams(-1, -2); modeLp.topMargin = dp(4); form.addView(modeButton, modeLp); modeButton.setOnClickListener(v -> setCreateMode(!creatingAccount));
        spinner = new ProgressBar(this); spinner.setVisibility(View.GONE); LinearLayout.LayoutParams spLp = new LinearLayout.LayoutParams(dp(32), dp(32)); spLp.gravity = Gravity.CENTER_HORIZONTAL; spLp.topMargin = dp(14); form.addView(spinner, spLp);
        loadingText = text("", 12, muted, false); loadingText.setGravity(Gravity.CENTER); form.addView(loadingText);
        Button local = button("Continue without an account", false); LinearLayout.LayoutParams localLp = new LinearLayout.LayoutParams(-1, -2); localLp.topMargin = dp(12); page.addView(local, localLp); local.setOnClickListener(v -> enterTracker("guest"));
    }

    private void buildSignedIn(LinearLayout page, FirebaseUser user) {
        LinearLayout card = column(); card.setPadding(dp(18), dp(18), dp(18), dp(18)); card.setBackground(rounded(surface, 18)); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(20); page.addView(card, lp);
        TextView status = text("Signed in", 18, ink, true); card.addView(status);
        TextView email = text(user.getEmail() == null ? "Google account" : user.getEmail(), 14, muted, false); LinearLayout.LayoutParams emailLp = new LinearLayout.LayoutParams(-1, -2); emailLp.topMargin = dp(7); card.addView(email, emailLp);
        signOutButton = button("Sign out", false); LinearLayout.LayoutParams outLp = new LinearLayout.LayoutParams(-1, -2); outLp.topMargin = dp(17); card.addView(signOutButton, outLp); signOutButton.setOnClickListener(v -> confirmSignOut());
        deleteButton = button("Delete account", false); deleteButton.setTextColor(dark ? Color.rgb(255, 145, 135) : Color.rgb(176, 38, 36)); card.addView(deleteButton); deleteButton.setOnClickListener(v -> confirmDelete(user));
        spinner = new ProgressBar(this); spinner.setVisibility(View.GONE); LinearLayout.LayoutParams spinnerLp = new LinearLayout.LayoutParams(dp(32), dp(32)); spinnerLp.gravity = Gravity.CENTER_HORIZONTAL; spinnerLp.topMargin = dp(12); card.addView(spinner, spinnerLp);
        loadingText = text("", 12, muted, false); loadingText.setGravity(Gravity.CENTER); card.addView(loadingText);
    }

    private void setCreateMode(boolean create) {
        creatingAccount = create; errorText.setVisibility(View.GONE);
        emailButton.setText(create ? "Create account" : "Sign in"); modeButton.setText(create ? "I already have an account" : "Create an account");
    }

    private void submitEmail() {
        String email = emailInput.getText().toString().trim(); String password = passwordInput.getText().toString(); errorText.setVisibility(View.GONE);
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) { emailInput.setError("Enter a valid email address"); return; }
        if (password.isEmpty()) { passwordInput.setError("Enter your password"); return; }
        if (creatingAccount && password.length() < 6) { passwordInput.setError("Use at least 6 characters"); return; }
        setLoading(true, creatingAccount ? "Creating your account…" : "Signing in…");
        if (creatingAccount) auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(this, task -> finishAuthTask(task.isSuccessful(), task.getException(), "Account created."));
        else auth.signInWithEmailAndPassword(email, password).addOnCompleteListener(this, task -> finishAuthTask(task.isSuccessful(), task.getException(), "Signed in."));
    }

    private void finishAuthTask(boolean success, Exception exception, String successMessage) {
        setLoading(false, ""); clearPassword();
        if (success) { Toast.makeText(this, successMessage, Toast.LENGTH_SHORT).show(); enterTracker("account"); }
        else showError(authError(exception));
    }

    private void beginGoogleFlow(boolean reauthenticate) {
        int clientId = getResources().getIdentifier("default_web_client_id", "string", getPackageName());
        if (clientId == 0) { showError("Google sign-in is not configured yet. Add your Firebase app configuration first."); return; }
        setLoading(true, "Opening Google sign-in…");
        try {
            // This screen launches from an explicit Google button, so use the dedicated
            // Sign in with Google Credential Manager option rather than the bottom-sheet option.
            GetSignInWithGoogleOption option = new GetSignInWithGoogleOption.Builder(getString(clientId)).build();
            GetCredentialRequest request = new GetCredentialRequest.Builder().addCredentialOption(option).build();
            Executor mainExecutor = ContextCompat.getMainExecutor(this);
            credentialManager.getCredentialAsync(this, request, null, mainExecutor, new androidx.credentials.CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                @Override public void onResult(GetCredentialResponse response) {
                    Credential credential = response.getCredential();
                    if (!(credential instanceof CustomCredential) || !GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(credential.getType())) {
                        setLoading(false, ""); showError("Google returned an unsupported sign-in response. Try email sign-in instead."); return;
                    }
                    String token;
                    try { token = GoogleIdTokenCredential.createFrom(((CustomCredential) credential).getData()).getIdToken(); }
                    catch (Exception ex) { setLoading(false, ""); showError("Could not read the Google sign-in response. Try again."); return; }
                    AuthCredential firebaseCredential = GoogleAuthProvider.getCredential(token, null);
                    if (reauthenticate) reauthenticateAndDelete(firebaseCredential); else signInGoogle(firebaseCredential);
                }
                @Override public void onError(GetCredentialException exception) {
                    setLoading(false, "");
                    if (exception instanceof GetCredentialCancellationException) showError("Google sign-in was canceled. Your local expenses were not changed.");
                    else {
                        String failure = exception.getClass().getSimpleName();
                        if ("NoCredentialException".equals(failure)) showError("No Google account is available for sign-in. Add a Google account to the emulator and try again.");
                        else if (failure.contains("ProviderConfiguration")) showError("Google sign-in is unavailable on this device. Update Google Play services and try again.");
                        else showError("Google sign-in failed (" + failure + "). Check Google Play services and that Google sign-in is enabled in Firebase.");
                    }
                }
            });
        } catch (Exception exception) { setLoading(false, ""); showError("Google sign-in could not start. Check your Firebase setup and try again."); }
    }

    private void signInGoogle(AuthCredential credential) {
        setLoading(true, "Signing in with Google…");
        auth.signInWithCredential(credential).addOnCompleteListener(this, task -> {
            setLoading(false, "");
            if (task.isSuccessful()) { Toast.makeText(this, "Signed in with Google.", Toast.LENGTH_SHORT).show(); enterTracker("account"); }
            else showError(authError(task.getException()));
        });
    }

    private void confirmSignOut() {
        new AlertDialog.Builder(this).setTitle("Sign out?").setMessage("Your account will be signed out. Expenses and budgets on this device will stay here.")
                .setNegativeButton("Cancel", null).setPositiveButton("Sign out", (dialog, which) -> {
                    auth.signOut();
                    try { credentialManager.clearCredentialStateAsync(new ClearCredentialStateRequest(), null, ContextCompat.getMainExecutor(this), new androidx.credentials.CredentialManagerCallback<Void, ClearCredentialException>() {
                        @Override public void onResult(Void result) { returnToExpenseTracker(); }
                        @Override public void onError(ClearCredentialException e) { returnToExpenseTracker(); }
                    }); } catch (Exception ignored) { returnToExpenseTracker(); }
                }).show();
    }

    private void returnToExpenseTracker() {
        getSharedPreferences("spendwise", MODE_PRIVATE).edit().putBoolean("welcome_completed", false).putString("account_mode", "signed_out").apply();
        Toast.makeText(this, "Signed out. Your local expenses are still available.", Toast.LENGTH_SHORT).show();
        Intent welcome = new Intent(this, AccountActivity.class);
        welcome.putExtra(EXTRA_FIRST_LAUNCH, true);
        startActivity(welcome);
        finish();
    }

    private void enterTracker(String mode) {
        getSharedPreferences("spendwise", MODE_PRIVATE).edit().putBoolean("welcome_completed", true).putString("account_mode", mode).apply();
        if (firstLaunch) {
            Intent tracker = new Intent(this, MainActivity.class);
            tracker.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(tracker);
        }
        finish();
    }

    private void confirmDelete(FirebaseUser user) {
        new AlertDialog.Builder(this).setTitle("Delete account?").setMessage("This permanently deletes your Firebase sign-in account. Expenses and budgets stored on this device will remain. You may need to verify your sign-in again.")
                .setNegativeButton("Cancel", null).setPositiveButton("Continue", (dialog, which) -> reauthenticateForDelete(user)).show();
    }

    private void reauthenticateForDelete(FirebaseUser user) {
        boolean emailProvider = false;
        for (com.google.firebase.auth.UserInfo info : user.getProviderData()) if ("password".equals(info.getProviderId())) emailProvider = true;
        if (emailProvider) {
            EditText password = input("Confirm your password", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            password.setSaveEnabled(false);
            AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Verify your password").setMessage("Firebase requires a recent sign-in to delete an account.").setView(password).setNegativeButton("Cancel", null).setPositiveButton("Verify and delete", null).create();
            dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String value = password.getText().toString(); if (value.isEmpty()) { password.setError("Enter your password"); return; }
                dialog.dismiss(); setLoading(true, "Verifying account…");
                AuthCredential credential = EmailAuthProvider.getCredential(user.getEmail(), value); value = null; password.setText("");
                user.reauthenticate(credential).addOnCompleteListener(this, task -> { if (task.isSuccessful()) deleteFirebaseAccount(user); else { setLoading(false, ""); showError(authError(task.getException())); } });
            })); dialog.show();
        } else beginGoogleFlow(true);
    }

    private void reauthenticateAndDelete(AuthCredential credential) {
        FirebaseUser user = auth.getCurrentUser(); if (user == null) { setLoading(false, ""); showError("You are signed out. Sign in again before deleting your account."); return; }
        user.reauthenticate(credential).addOnCompleteListener(this, task -> { if (task.isSuccessful()) deleteFirebaseAccount(user); else { setLoading(false, ""); showError(authError(task.getException())); } });
    }

    private void deleteFirebaseAccount(FirebaseUser user) {
        user.delete().addOnCompleteListener(this, task -> {
            setLoading(false, "");
            if (task.isSuccessful()) { getSharedPreferences("spendwise", MODE_PRIVATE).edit().putBoolean("welcome_completed", false).putString("account_mode", "signed_out").apply(); Toast.makeText(this, "Account deleted. Local expenses are still on this device.", Toast.LENGTH_LONG).show(); finish(); }
            else showError(authError(task.getException()));
        });
    }

    private String authError(Exception error) {
        if (error instanceof FirebaseNetworkException) return "Network error. Check your internet connection and try again.";
        if (error instanceof FirebaseAuthUserCollisionException) return "An account already exists for this email. Sign in instead, or use the Google account linked to it.";
        if (error instanceof FirebaseAuthInvalidCredentialsException) return "That email or password is invalid. Check the details and try again.";
        if (error instanceof FirebaseTooManyRequestsException) return "Too many attempts. Wait a little while, then try again.";
        if (error instanceof FirebaseAuthException) {
            String code = ((FirebaseAuthException) error).getErrorCode();
            if (code != null && code.contains("OPERATION_NOT_ALLOWED")) return "This sign-in method is disabled in Firebase. Enable Google or Email/Password under Authentication → Sign-in method, then save.";
            if (code != null && (code.contains("EMAIL_ALREADY_IN_USE") || code.contains("ACCOUNT_EXISTS_WITH_DIFFERENT_CREDENTIAL"))) return "An account already exists for this email. Sign in instead.";
            if (code != null && code.contains("WEAK_PASSWORD")) return "Choose a stronger password with at least 6 characters.";
            if (code != null && (code.contains("WRONG_PASSWORD") || code.contains("INVALID_CREDENTIAL") || code.contains("USER_NOT_FOUND"))) return "Email or password not recognized. Check the details and try again.";
            if (code != null && code.contains("RECENT_LOGIN_REQUIRED")) return "For security, sign in again and repeat account deletion.";
        }
        return error == null ? "Something went wrong. Please try again." : "Could not complete sign-in. Check your details and Firebase setup, then try again.";
    }

    private void rebuild() { root.removeAllViews(); buildScreen(); }
    private void setLoading(boolean loading, String message) {
        if (spinner != null) spinner.setVisibility(loading ? View.VISIBLE : View.GONE);
        if (loadingText != null) loadingText.setText(message);
        if (googleButton != null) googleButton.setEnabled(!loading);
        if (emailButton != null) emailButton.setEnabled(!loading);
        if (modeButton != null) modeButton.setEnabled(!loading);
        if (signOutButton != null) signOutButton.setEnabled(!loading);
        if (deleteButton != null) deleteButton.setEnabled(!loading);
    }
    private void showError(String message) { if (errorText != null && configured && auth.getCurrentUser() == null) { errorText.setText(message); errorText.setVisibility(View.VISIBLE); } else Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }
    private void clearPassword() { if (passwordInput != null) passwordInput.setText(""); }
    private Button button(String label, boolean primary) { Button b = new Button(this); b.setText(label); b.setTextSize(14); b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setTextColor(primary ? buttonInk : (dark ? ink : Color.rgb(34, 83, 126))); b.setBackground(rounded(primary ? amberFill : soft, 14)); return b; }
    private EditText input(String hint, int type) { EditText e = new EditText(this); e.setSingleLine(true); e.setTextSize(14); e.setInputType(type); e.setHint(hint); return e; }
    private void addGap(LinearLayout layout, int size) { View gap = new View(this); layout.addView(gap, new LinearLayout.LayoutParams(1, dp(size))); }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private TextView text(String value, int size, int color, boolean bold) { TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t; }
    private GradientDrawable rounded(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + .5f); }
}
