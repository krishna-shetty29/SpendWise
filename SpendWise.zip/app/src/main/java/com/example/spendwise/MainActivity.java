package com.example.spendwise;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.content.res.Configuration;
import android.net.Uri;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private int ink, muted, green, amberFill, blueCard, canvas, surface, chipSurface, softAccent, track, dividerColor;
    private boolean darkMode;
    private final String[] categories = {"Food", "Transport", "Shopping", "Bills", "Health", "Other"};
    private final ArrayList<Expense> expenses = new ArrayList<>();
    private final LinkedHashMap<String, Double> budgets = new LinkedHashMap<>();
    private String selectedCategory = "All";
    private Calendar displayedMonth = Calendar.getInstance();
    private LinearLayout page, list, chartRows;
    private TextView totalText, countText, monthText, monthHeading, budgetAmountText, budgetHintText, progressPercent;
    private ProgressBar budgetProgress;
    private TextView greetingText;
    private ImageView profileAvatar;
    private TextView avatarInitial;

    private static class Expense {
        String title, category, date;
        double amount;
        Expense(String title, String category, String date, double amount) {
            this.title = title; this.category = category; this.date = date; this.amount = amount;
        }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        applySavedThemeMode();
        setTheme(R.style.Theme_SpendWise);
        super.onCreate(savedInstanceState);
        if (shouldShowWelcome()) {
            android.content.Intent welcome = new android.content.Intent(this, AccountActivity.class);
            welcome.putExtra(AccountActivity.EXTRA_FIRST_LAUNCH, true);
            startActivity(welcome);
            finish();
            return;
        }
        applyPalette();
        WindowCompat.enableEdgeToEdge(getWindow());
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        getWindow().getDecorView().setSystemUiVisibility(darkMode ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        loadData();
        setContentView(R.layout.activity_main);
        FrameLayout root = findViewById(R.id.main);
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });
        buildScreen(root);
    }

    @Override protected void onResume() {
        super.onResume();
        if (greetingText != null) refreshProfileHeader();
    }

    private boolean shouldShowWelcome() {
        android.content.SharedPreferences prefs = getSharedPreferences("spendwise", MODE_PRIVATE);
        boolean hasSignedInAccount = !FirebaseApp.getApps(this).isEmpty()
                && FirebaseAuth.getInstance().getCurrentUser() != null;
        if (hasSignedInAccount) {
            prefs.edit().putBoolean("welcome_completed", true).putString("account_mode", "account").apply();
            return false;
        }
        return !prefs.getBoolean("welcome_completed", false);
    }

    private void buildScreen(FrameLayout root) {
        root.setBackgroundColor(canvas);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true); scroll.setClipToPadding(false);
        page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(18), dp(22), dp(112)); scroll.addView(page);
        root.addView(scroll, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout header = row();
        ImageView brandMark = new ImageView(this); brandMark.setImageResource(R.drawable.ic_spendwise_mark); brandMark.setContentDescription("SpendWise logo"); brandMark.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams brandLp = new LinearLayout.LayoutParams(dp(46), dp(46)); brandLp.rightMargin = dp(10); header.addView(brandMark, brandLp);
        LinearLayout titles = column(); greetingText = label("Good to see you.", 15, ink, true); titles.addView(greetingText); titles.addView(label("Let’s manage money", 18, muted, false));
        header.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        FrameLayout avatar = new FrameLayout(this); avatar.setBackground(circle(softAccent)); avatar.setClipToOutline(true); avatar.setContentDescription("Profile and settings");
        avatarInitial = label("S", 16, green, true); avatarInitial.setGravity(Gravity.CENTER); avatar.addView(avatarInitial, new FrameLayout.LayoutParams(-1,-1));
        profileAvatar = new ImageView(this); profileAvatar.setScaleType(ImageView.ScaleType.CENTER_CROP); profileAvatar.setVisibility(View.GONE); avatar.addView(profileAvatar, new FrameLayout.LayoutParams(-1,-1));
        avatar.setOnClickListener(v -> showSettingsDialog()); header.addView(avatar, new LinearLayout.LayoutParams(dp(44), dp(44))); page.addView(header);
        refreshProfileHeader();

        LinearLayout monthNav = row(); monthNav.setGravity(Gravity.CENTER_VERTICAL);
        TextView previous = label("‹", 30, ink, false); previous.setGravity(Gravity.CENTER); monthNav.addView(previous, new LinearLayout.LayoutParams(dp(42), dp(42)));
        monthHeading = label("", 15, ink, true); monthHeading.setGravity(Gravity.CENTER); monthNav.addView(monthHeading, new LinearLayout.LayoutParams(0, -2, 1));
        TextView next = label("›", 30, ink, false); next.setGravity(Gravity.CENTER); monthNav.addView(next, new LinearLayout.LayoutParams(dp(42), dp(42)));
        LinearLayout.LayoutParams navLp = new LinearLayout.LayoutParams(-1, -2); navLp.topMargin = dp(12); page.addView(monthNav, navLp);
        previous.setOnClickListener(v -> shiftMonth(-1)); next.setOnClickListener(v -> shiftMonth(1));

        LinearLayout hero = column(); hero.setPadding(dp(20), dp(19), dp(20), dp(18)); hero.setBackground(round(blueCard, 22));
        LinearLayout.LayoutParams heroLp = new LinearLayout.LayoutParams(-1, -2); heroLp.topMargin = dp(8); page.addView(hero, heroLp);
        LinearLayout heroTitle = row(); heroTitle.addView(label("TOTAL SPENT", 11, Color.rgb(203, 226, 211), true), new LinearLayout.LayoutParams(0, -2, 1));
        TextView badge = label("●  Selected month", 11, Color.WHITE, true); badge.setBackground(round(darkMode ? Color.rgb(47, 91, 133) : Color.rgb(50, 103, 151), 30)); badge.setPadding(dp(10), dp(7), dp(10), dp(7)); heroTitle.addView(badge); hero.addView(heroTitle);
        totalText = label("₹0.00", 34, darkMode ? Color.rgb(255, 197, 79) : Color.rgb(255, 209, 102), true); LinearLayout.LayoutParams totalLp = new LinearLayout.LayoutParams(-2, -2); totalLp.topMargin = dp(10); hero.addView(totalText, totalLp);
        View divider = new View(this); divider.setBackgroundColor(dividerColor); LinearLayout.LayoutParams dividerLp = new LinearLayout.LayoutParams(-1, dp(1)); dividerLp.topMargin = dp(15); dividerLp.bottomMargin = dp(13); hero.addView(divider, dividerLp);
        LinearLayout summary = row(); summary.addView(label("⌁  Keep your spending on track", 12, Color.rgb(221, 237, 225), false), new LinearLayout.LayoutParams(0, -2, 1));
        countText = label("0 expenses", 12, Color.WHITE, true); summary.addView(countText); hero.addView(summary);

        LinearLayout budgetCard = column(); budgetCard.setPadding(dp(17), dp(16), dp(17), dp(16)); budgetCard.setBackground(round(surface, 18));
        LinearLayout.LayoutParams budgetLp = new LinearLayout.LayoutParams(-1, -2); budgetLp.topMargin = dp(16); page.addView(budgetCard, budgetLp);
        LinearLayout budgetHead = row(); budgetHead.addView(label("Monthly budget", 16, ink, true), new LinearLayout.LayoutParams(0, -2, 1));
        TextView editBudget = label("Set budget", 12, green, true); editBudget.setPadding(dp(11), dp(7), dp(11), dp(7)); editBudget.setBackground(round(softAccent, 18)); budgetHead.addView(editBudget); budgetCard.addView(budgetHead); editBudget.setOnClickListener(v -> showBudgetDialog());
        LinearLayout budgetInfo = row(); budgetInfo.setGravity(Gravity.CENTER_VERTICAL); LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(-1, -2); infoLp.topMargin = dp(13); budgetCard.addView(budgetInfo, infoLp);
        LinearLayout budgetLabels = column(); budgetLabels.addView(label("SPENT / LIMIT", 10, muted, true)); budgetAmountText = label("₹0 / Not set", 14, ink, true); LinearLayout.LayoutParams amountLp = new LinearLayout.LayoutParams(-2, -2); amountLp.topMargin = dp(4); budgetLabels.addView(budgetAmountText, amountLp);
        budgetInfo.addView(budgetLabels, new LinearLayout.LayoutParams(0, -2, 1)); progressPercent = label("0%", 13, green, true); budgetInfo.addView(progressPercent);
        budgetProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal); budgetProgress.setMax(100); budgetProgress.setProgress(0); budgetProgress.setProgressDrawable(progressDrawable(green));
        LinearLayout.LayoutParams progressLp = new LinearLayout.LayoutParams(-1, dp(9)); progressLp.topMargin = dp(12); budgetCard.addView(budgetProgress, progressLp);
        budgetHintText = label("Set a budget to track your monthly spending.", 11, muted, false); LinearLayout.LayoutParams hintLp = new LinearLayout.LayoutParams(-1, -2); hintLp.topMargin = dp(8); budgetCard.addView(budgetHintText, hintLp);

        LinearLayout chartCard = column(); chartCard.setPadding(dp(17), dp(16), dp(17), dp(14)); chartCard.setBackground(round(surface, 18));
        LinearLayout.LayoutParams chartLp = new LinearLayout.LayoutParams(-1, -2); chartLp.topMargin = dp(16); page.addView(chartCard, chartLp);
        LinearLayout chartHeader = row(); chartHeader.addView(label("Spending by category", 16, ink, true), new LinearLayout.LayoutParams(0, -2, 1)); chartHeader.addView(label("Selected month", 11, muted, false)); chartCard.addView(chartHeader);
        TextView chartTotal = label("Category totals for " + monthLabel(), 11, muted, false); LinearLayout.LayoutParams chartTotalLp = new LinearLayout.LayoutParams(-1, -2); chartTotalLp.topMargin = dp(4); chartCard.addView(chartTotal, chartTotalLp);
        chartRows = column(); LinearLayout.LayoutParams chartRowsLp = new LinearLayout.LayoutParams(-1, -2); chartRowsLp.topMargin = dp(15); chartCard.addView(chartRows, chartRowsLp);

        LinearLayout section = row(); section.setGravity(Gravity.CENTER_VERTICAL); TextView recent = label("Expenses", 19, ink, true); section.addView(recent, new LinearLayout.LayoutParams(0, -2, 1));
        monthText = label("", 12, muted, false); section.addView(monthText); LinearLayout.LayoutParams sectionLp = new LinearLayout.LayoutParams(-1, -2); sectionLp.topMargin = dp(24); sectionLp.bottomMargin = dp(12); page.addView(section, sectionLp);
        ScrollView categoriesScroll = new ScrollView(this); categoriesScroll.setHorizontalScrollBarEnabled(false); LinearLayout chips = row(); categoriesScroll.addView(chips);
        String[] filters = {"All", "Food", "Transport", "Shopping", "Bills", "Health", "Other"};
        for (String cat : filters) {
            TextView chip = label(cat, 12, cat.equals(selectedCategory) ? Color.rgb(35, 38, 42) : muted, cat.equals(selectedCategory)); chip.setGravity(Gravity.CENTER); chip.setPadding(dp(15), dp(9), dp(15), dp(9)); chip.setBackground(round(cat.equals(selectedCategory) ? amberFill : chipSurface, 24));
            LinearLayout.LayoutParams chipLp = new LinearLayout.LayoutParams(-2, -2); chipLp.rightMargin = dp(8); chips.addView(chip, chipLp); chip.setOnClickListener(v -> { selectedCategory = cat; renderData(); });
        }
        page.addView(categoriesScroll); list = column(); LinearLayout.LayoutParams listLp = new LinearLayout.LayoutParams(-1, -2); listLp.topMargin = dp(14); page.addView(list, listLp);
        TextView add = label("+", 30, Color.rgb(35, 38, 42), true); add.setGravity(Gravity.CENTER); add.setBackground(circle(amberFill)); add.setElevation(dp(8));
        FrameLayout.LayoutParams fabLp = new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.BOTTOM | Gravity.END); fabLp.setMargins(0, 0, dp(22), dp(22)); root.addView(add, fabLp); add.setOnClickListener(v -> showExpenseDialog(null));
        renderData();
    }

    private void renderData() {
        String month = monthKey(displayedMonth);
        monthHeading.setText(monthLabel()); monthText.setText(monthLabel());
        double total = 0; int count = 0;
        for (Expense e : expenses) if (monthKey(e.date).equals(month)) { total += e.amount; count++; }
        totalText.setText(money(total)); countText.setText(count + (count == 1 ? " expense" : " expenses"));
        updateBudget(total, budgets.containsKey(month) ? budgets.get(month) : 0d);
        renderChart(month, total);
        renderExpenseList(month);
    }

    private void updateBudget(double spent, double limit) {
        if (limit <= 0) { budgetAmountText.setText(money(spent) + " / Not set"); progressPercent.setText("—"); budgetProgress.setProgress(0); budgetProgress.setProgressDrawable(progressDrawable(green)); budgetHintText.setText("Set a budget to track your monthly spending."); return; }
        int progress = (int) Math.min(100, Math.round(spent / limit * 100)); boolean over = spent > limit;
        budgetAmountText.setText(money(spent) + " / " + money(limit)); progressPercent.setText(over ? "Over budget" : progress + "%");
        budgetProgress.setProgress(progress); budgetProgress.setProgressDrawable(progressDrawable(over ? Color.rgb(197, 76, 67) : amberFill));
        budgetHintText.setText(over ? money(spent - limit) + " over your budget" : money(limit - spent) + " left to spend");
    }

    private void renderChart(String month, double total) {
        chartRows.removeAllViews();
        LinkedHashMap<String, Double> sums = new LinkedHashMap<>(); for (String category : categories) sums.put(category, 0d);
        for (Expense e : expenses) if (monthKey(e.date).equals(month)) sums.put(e.category, sums.getOrDefault(e.category, 0d) + e.amount);
        if (total <= 0) { TextView empty = label("No spending recorded for this month yet.", 12, muted, false); empty.setGravity(Gravity.CENTER); empty.setPadding(0, dp(14), 0, dp(14)); chartRows.addView(empty); return; }
        for (Map.Entry<String, Double> entry : sums.entrySet()) {
            if (entry.getValue() <= 0) continue;
            LinearLayout line = row(); TextView name = label(entry.getKey(), 12, ink, true); line.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
            TextView amount = label(money(entry.getValue()), 12, ink, true); amount.setGravity(Gravity.RIGHT); line.addView(amount); chartRows.addView(line);
            ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal); bar.setMax(100); bar.setProgress((int) Math.round(entry.getValue() / total * 100)); bar.setProgressDrawable(progressDrawable(categoryColor(entry.getKey())));
            LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(-1, dp(7)); barLp.topMargin = dp(7); barLp.bottomMargin = dp(12); chartRows.addView(bar, barLp);
        }
    }

    private void renderExpenseList(String month) {
        list.removeAllViews(); ArrayList<Expense> shown = new ArrayList<>();
        for (Expense e : expenses) if (monthKey(e.date).equals(month) && (selectedCategory.equals("All") || selectedCategory.equals(e.category))) shown.add(e);
        if (shown.isEmpty()) {
            LinearLayout empty = column(); empty.setGravity(Gravity.CENTER); empty.setPadding(dp(18), dp(27), dp(18), dp(27)); empty.setBackground(round(surface, 18));
            TextView icon = label(expenses.isEmpty() ? "✦" : "⌕", 27, green, false); icon.setGravity(Gravity.CENTER); empty.addView(icon);
            TextView title = label(expenses.isEmpty() ? "Your spending starts here" : "No expenses for " + monthLabel(), 15, ink, true); title.setGravity(Gravity.CENTER); LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2); titleLp.topMargin = dp(8); empty.addView(title, titleLp);
            TextView hint = label(expenses.isEmpty() ? "Tap + to add your first expense" : "Try another month or category", 12, muted, false); hint.setGravity(Gravity.CENTER); LinearLayout.LayoutParams hintLp = new LinearLayout.LayoutParams(-1, -2); hintLp.topMargin = dp(5); empty.addView(hint, hintLp); list.addView(empty); return;
        }
        for (Expense e : shown) {
            LinearLayout item = row(); item.setGravity(Gravity.CENTER_VERTICAL); item.setPadding(dp(13), dp(12), dp(13), dp(12)); item.setBackground(round(surface, 17));
            LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(-1, -2); itemLp.bottomMargin = dp(9); list.addView(item, itemLp);
            TextView icon = label(categoryIcon(e.category), 20, green, false); icon.setGravity(Gravity.CENTER); icon.setBackground(round(categoryTint(e.category), 14)); item.addView(icon, new LinearLayout.LayoutParams(dp(46), dp(46)));
            LinearLayout detail = column(); detail.setPadding(dp(12), 0, dp(7), 0); item.addView(detail, new LinearLayout.LayoutParams(0, -2, 1));
            TextView title = label(e.title, 14, ink, true); title.setMaxLines(1); title.setEllipsize(android.text.TextUtils.TruncateAt.END); detail.addView(title);
            TextView meta = label(e.category + "  ·  " + displayDate(e.date), 11, muted, false); LinearLayout.LayoutParams metaLp = new LinearLayout.LayoutParams(-2, -2); metaLp.topMargin = dp(5); detail.addView(meta, metaLp);
            TextView value = label("− " + money(e.amount), 13, ink, true); item.addView(value);
            View.OnClickListener actions = v -> showExpenseActions(e); item.setOnClickListener(actions); item.setOnLongClickListener(v -> { showExpenseActions(e); return true; });
        }
    }

    private void showExpenseActions(Expense expense) {
        new AlertDialog.Builder(this).setTitle(expense.title).setItems(new String[]{"Edit expense", "Delete expense"}, (dialog, which) -> {
            if (which == 0) showExpenseDialog(expense);
            else new AlertDialog.Builder(this).setTitle("Delete expense?").setMessage("Delete “" + expense.title + "” (" + money(expense.amount) + ")? This cannot be undone.")
                    .setNegativeButton("Cancel", null).setPositiveButton("Delete", (d, w) -> { expenses.remove(expense); saveData(); renderData(); Toast.makeText(this, "Expense deleted", Toast.LENGTH_SHORT).show(); }).show();
        }).show();
    }

    private void showExpenseDialog(Expense existing) {
        Calendar chosen = Calendar.getInstance();
        if (existing != null) { Calendar parsed = parseCalendar(existing.date); if (parsed != null) chosen = parsed; }
        final Calendar dateValue = chosen;
        LinearLayout form = column(); form.setPadding(dp(22), dp(4), dp(22), 0);
        EditText title = input("What did you spend on?", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        EditText amount = input("Amount (₹)", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        Spinner category = new Spinner(this); ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, categories); category.setAdapter(adapter);
        TextView dateButton = label("", 14, green, true); dateButton.setPadding(dp(12), dp(12), dp(12), dp(12)); dateButton.setBackground(round(softAccent, 12));
        updateDateButton(dateButton, dateValue); dateButton.setOnClickListener(v -> showDatePicker(dateValue, dateButton));
        form.addView(label("DESCRIPTION", 10, muted, true)); form.addView(title); addGap(form, 7); form.addView(label("AMOUNT", 10, muted, true)); form.addView(amount);
        addGap(form, 8); form.addView(label("CATEGORY", 10, muted, true)); form.addView(category); addGap(form, 8); form.addView(label("DATE", 10, muted, true)); form.addView(dateButton);
        if (existing != null) { title.setText(existing.title); amount.setText(String.valueOf(existing.amount)); for (int i = 0; i < categories.length; i++) if (categories[i].equals(existing.category)) category.setSelection(i); }
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(existing == null ? "Add expense" : "Edit expense").setView(form).setNegativeButton("Cancel", null).setPositiveButton(existing == null ? "Save" : "Update", null).create();
        dialog.setOnShowListener(d -> { dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(green); dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = title.getText().toString().trim(); String rawAmount = amount.getText().toString().trim();
            if (name.isEmpty()) { title.setError("Enter a description"); return; }
            double value;
            try { value = Double.parseDouble(rawAmount); } catch (NumberFormatException ex) { amount.setError("Enter a valid amount"); return; }
            if (!Double.isFinite(value) || value <= 0) { amount.setError("Amount must be greater than zero"); return; }
            String isoDate = formatDate(dateValue);
            if (!isValidDate(isoDate) || isoDate.compareTo(formatDate(Calendar.getInstance())) > 0) { Toast.makeText(this, "Choose a valid date that is not in the future", Toast.LENGTH_SHORT).show(); return; }
            if (existing == null) expenses.add(0, new Expense(name, categories[category.getSelectedItemPosition()], isoDate, value));
            else { existing.title = name; existing.amount = value; existing.category = categories[category.getSelectedItemPosition()]; existing.date = isoDate; }
            saveData(); dialog.dismiss(); renderData();
        }); }); dialog.show();
    }

    private void showDatePicker(Calendar date, TextView target) {
        DatePickerDialog picker = new DatePickerDialog(this, (view, year, month, day) -> {
            date.set(year, month, day, 12, 0, 0); date.set(Calendar.MILLISECOND, 0); updateDateButton(target, date);
        }, date.get(Calendar.YEAR), date.get(Calendar.MONTH), date.get(Calendar.DAY_OF_MONTH));
        picker.getDatePicker().setMaxDate(System.currentTimeMillis()); picker.show();
    }

    private void showBudgetDialog() {
        EditText input = input("Monthly limit in ₹", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        double current = budgets.containsKey(monthKey(displayedMonth)) ? budgets.get(monthKey(displayedMonth)) : 0;
        if (current > 0) input.setText(String.valueOf(current));
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Budget for " + monthLabel()).setMessage("Set a monthly spending limit.").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Save", null).create();
        if (current > 0) dialog.setButton(AlertDialog.BUTTON_NEUTRAL, "Remove", (d, w) -> { budgets.remove(monthKey(displayedMonth)); saveData(); renderData(); });
        dialog.setOnShowListener(d -> { dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(green); if (current > 0) dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(Color.rgb(197, 76, 67));
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> { double value; try { value = Double.parseDouble(input.getText().toString().trim()); } catch (NumberFormatException ex) { input.setError("Enter a valid budget"); return; }
                if (!Double.isFinite(value) || value <= 0) { input.setError("Budget must be greater than zero"); return; }
                budgets.put(monthKey(displayedMonth), value); saveData(); dialog.dismiss(); renderData(); }); }); dialog.show();
    }

    private void shiftMonth(int amount) { displayedMonth.add(Calendar.MONTH, amount); selectedCategory = "All"; rebuildContent(); }
    private void rebuildContent() { FrameLayout root = findViewById(R.id.main); root.removeAllViews(); buildScreen(root); }
    private EditText input(String hint, int type) { EditText edit = new EditText(this); edit.setSingleLine(true); edit.setTextSize(14); edit.setInputType(type); edit.setHint(hint); return edit; }
    private void addGap(LinearLayout parent, int height) { View gap = new View(this); parent.addView(gap, new LinearLayout.LayoutParams(1, dp(height))); }
    private void updateDateButton(TextView button, Calendar date) { button.setText("▦   " + new SimpleDateFormat("EEE, d MMM yyyy", Locale.getDefault()).format(date.getTime())); }
    private String normalizeCategory(String raw) { for (String category : categories) if (category.equalsIgnoreCase(raw)) return category; return "Other"; }
    private String money(double amount) { return "₹" + String.format(Locale.getDefault(), "%,.2f", amount); }
    private String monthLabel() { return new SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(displayedMonth.getTime()); }
    private String monthKey(Calendar calendar) { return new SimpleDateFormat("yyyy-MM", Locale.US).format(calendar.getTime()); }
    private String monthKey(String iso) { return iso.length() >= 7 ? iso.substring(0, 7) : ""; }
    private String formatDate(Calendar date) { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(date.getTime()); }
    private String displayDate(String iso) { Calendar date = parseCalendar(iso); return date == null ? iso : new SimpleDateFormat("d MMM", Locale.getDefault()).format(date.getTime()); }
    private Calendar parseCalendar(String raw) {
        try { SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US); fmt.setLenient(false); ParsePosition pos = new ParsePosition(0); Date parsed = fmt.parse(raw, pos); if (parsed != null && pos.getIndex() == raw.length()) { Calendar result = Calendar.getInstance(); result.setTime(parsed); return result; } } catch (Exception ignored) { }
        try { SimpleDateFormat old = new SimpleDateFormat("d MMM", Locale.getDefault()); old.setLenient(false); Calendar result = Calendar.getInstance(); result.setTime(old.parse(raw)); return result; } catch (Exception ignored) { return null; }
    }
    private boolean isValidDate(String iso) { Calendar date = parseCalendar(iso); return date != null && formatDate(date).equals(iso); }
    private LinearLayout row() { LinearLayout layout = new LinearLayout(this); layout.setOrientation(LinearLayout.HORIZONTAL); layout.setGravity(Gravity.CENTER_VERTICAL); return layout; }
    private LinearLayout column() { LinearLayout layout = new LinearLayout(this); layout.setOrientation(LinearLayout.VERTICAL); return layout; }
    private TextView label(String text, int size, int color, boolean bold) { TextView view = new TextView(this); view.setText(text); view.setTextSize(size); view.setTextColor(color); if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return view; }
    private GradientDrawable round(int color, int radius) { GradientDrawable shape = new GradientDrawable(); shape.setColor(color); shape.setCornerRadius(dp(radius)); return shape; }
    private GradientDrawable circle(int color) { GradientDrawable shape = new GradientDrawable(); shape.setColor(color); shape.setShape(GradientDrawable.OVAL); return shape; }
    private android.graphics.drawable.Drawable progressDrawable(int color) {
        android.graphics.drawable.ClipDrawable clip = new android.graphics.drawable.ClipDrawable(round(color, 12), Gravity.LEFT, android.graphics.drawable.ClipDrawable.HORIZONTAL);
        android.graphics.drawable.LayerDrawable layers = new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{round(track, 12), clip});
        layers.setId(0, android.R.id.background); layers.setId(1, android.R.id.progress); return layers;
    }
    private int categoryColor(String category) { switch (category) { case "Food": return Color.rgb(242, 177, 56); case "Transport": return Color.rgb(82, 159, 225); case "Shopping": return Color.rgb(139, 126, 219); case "Bills": return Color.rgb(91, 190, 196); case "Health": return Color.rgb(101, 183, 137); default: return Color.rgb(157, 174, 193); } }
    private int categoryTint(String category) { return blend(categoryColor(category), surface, .88f); }
    private int blend(int color, int other, float ratio) { return Color.rgb((int)(Color.red(color)*(1-ratio)+Color.red(other)*ratio), (int)(Color.green(color)*(1-ratio)+Color.green(other)*ratio), (int)(Color.blue(color)*(1-ratio)+Color.blue(other)*ratio)); }
    private String categoryIcon(String category) { switch (category) { case "Food": return "🍽"; case "Transport": return "🚕"; case "Shopping": return "🛍"; case "Bills": return "⌁"; case "Health": return "＋"; default: return "✦"; } }
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + .5f); }

    private void applySavedThemeMode() {
        String mode = getSharedPreferences("spendwise", MODE_PRIVATE).getString("theme_mode", "system");
        int delegateMode = "light".equals(mode) ? AppCompatDelegate.MODE_NIGHT_NO : "dark".equals(mode) ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM;
        AppCompatDelegate.setDefaultNightMode(delegateMode);
    }

    private void applyPalette() {
        darkMode = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        ink = darkMode ? Color.rgb(243, 246, 250) : Color.rgb(22, 37, 54);
        muted = darkMode ? Color.rgb(190, 202, 216) : Color.rgb(83, 101, 122);
        green = darkMode ? Color.rgb(255, 190, 65) : Color.rgb(153, 83, 0);
        amberFill = darkMode ? Color.rgb(255, 190, 65) : Color.rgb(242, 177, 56);
        blueCard = darkMode ? Color.rgb(31, 69, 105) : Color.rgb(36, 88, 136);
        canvas = darkMode ? Color.rgb(18, 18, 18) : Color.rgb(244, 247, 251);
        surface = darkMode ? Color.rgb(29, 43, 59) : Color.WHITE;
        chipSurface = darkMode ? Color.rgb(34, 53, 73) : Color.rgb(230, 238, 247);
        softAccent = darkMode ? Color.rgb(39, 67, 96) : Color.rgb(224, 236, 248);
        track = darkMode ? Color.rgb(61, 76, 94) : Color.rgb(222, 231, 240);
        dividerColor = darkMode ? Color.rgb(94, 135, 173) : Color.rgb(124, 166, 203);
    }

    private void showSettingsDialog() {
        new AlertDialog.Builder(this).setTitle("Settings").setItems(new String[]{"Profile", "Appearance", "Account and privacy"}, (dialog, which) -> {
            if (which == 0) startActivity(new android.content.Intent(this, ProfileActivity.class));
            else if (which == 1) showThemeDialog();
            else startActivity(new android.content.Intent(this, AccountActivity.class));
        }).show();
    }

    private void refreshProfileHeader() {
        android.content.SharedPreferences prefs = getSharedPreferences("spendwise_profile", MODE_PRIVATE);
        String name;
        if (prefs.getBoolean("profile_name_customized", false)) name = prefs.getString("profile_display_name", "").trim();
        else {
            name = "";
            if (!FirebaseApp.getApps(this).isEmpty()) {
                com.google.firebase.auth.FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                if (user != null && user.getDisplayName() != null) name = user.getDisplayName().trim();
            }
        }
        Calendar now = Calendar.getInstance(); int hour = now.get(Calendar.HOUR_OF_DAY);
        String period = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";
        greetingText.setText(name.isEmpty() ? "Good to see you." : period + ", " + name + ".");

        Uri photo = null;
        String localUri = prefs.getString("profile_photo_uri", null);
        if (localUri != null) {
            try { photo = Uri.parse(localUri); } catch (Exception ignored) { }
        } else if (!prefs.getBoolean("profile_photo_cleared", false) && !FirebaseApp.getApps(this).isEmpty()) {
            com.google.firebase.auth.FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser(); if (user != null) photo = user.getPhotoUrl();
        }
        String initialSource = name.isEmpty() ? "S" : name;
        avatarInitial.setText(initialSource.substring(0, 1).toUpperCase(Locale.getDefault()));
        ProfilePhotoLoader.loadInto(profileAvatar, photo, () -> { profileAvatar.setVisibility(View.VISIBLE); avatarInitial.setVisibility(View.GONE); }, () -> { profileAvatar.setVisibility(View.GONE); avatarInitial.setVisibility(View.VISIBLE); });
    }

    private void showThemeDialog() {
        String[] options = {"System Default", "Light", "Dark"};
        String mode = getSharedPreferences("spendwise", MODE_PRIVATE).getString("theme_mode", "system");
        int selected = "light".equals(mode) ? 1 : "dark".equals(mode) ? 2 : 0;
        new AlertDialog.Builder(this).setTitle("Appearance").setSingleChoiceItems(options, selected, (dialog, which) -> {
            String value = which == 1 ? "light" : which == 2 ? "dark" : "system";
            getSharedPreferences("spendwise", MODE_PRIVATE).edit().putString("theme_mode", value).apply();
            AppCompatDelegate.setDefaultNightMode(which == 1 ? AppCompatDelegate.MODE_NIGHT_NO : which == 2 ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
            dialog.dismiss();
        }).setNegativeButton("Cancel", null).show();
    }

    private void loadData() {
        android.content.SharedPreferences prefs = getSharedPreferences("spendwise", MODE_PRIVATE);
        try {
            JSONArray data = new JSONArray(prefs.getString("expenses", "[]"));
            for (int i = 0; i < data.length(); i++) {
                JSONObject obj = data.getJSONObject(i); String rawDate = obj.optString("date", formatDate(Calendar.getInstance()));
                Calendar parsed = parseCalendar(rawDate); String date = parsed == null ? formatDate(Calendar.getInstance()) : formatDate(parsed);
                double amount = obj.optDouble("amount", 0); if (amount <= 0 || !Double.isFinite(amount)) continue;
                expenses.add(new Expense(obj.optString("title", "Expense"), normalizeCategory(obj.optString("category", "Other")), date, amount));
            }
        } catch (Exception ignored) { expenses.clear(); }
        try { JSONObject savedBudgets = new JSONObject(prefs.getString("budgets", "{}")); java.util.Iterator<String> keys = savedBudgets.keys(); while (keys.hasNext()) { String key = keys.next(); double amount = savedBudgets.optDouble(key, 0); if (amount > 0 && key.matches("\\d{4}-\\d{2}")) budgets.put(key, amount); } } catch (Exception ignored) { budgets.clear(); }
        saveData();
    }

    private void saveData() {
        JSONArray expenseJson = new JSONArray();
        try { for (Expense expense : expenses) { JSONObject obj = new JSONObject(); obj.put("title", expense.title); obj.put("category", expense.category); obj.put("date", expense.date); obj.put("amount", expense.amount); expenseJson.put(obj); } } catch (Exception ignored) { }
        JSONObject budgetJson = new JSONObject();
        try { for (Map.Entry<String, Double> entry : budgets.entrySet()) budgetJson.put(entry.getKey(), entry.getValue()); } catch (Exception ignored) { }
        getSharedPreferences("spendwise", MODE_PRIVATE).edit().putString("expenses", expenseJson.toString()).putString("budgets", budgetJson.toString()).apply();
    }
}
