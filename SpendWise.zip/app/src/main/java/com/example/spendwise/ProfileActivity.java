package com.example.spendwise;

import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.PickVisualMediaRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

/** Device-only profile customizations for SpendWise. */
public class ProfileActivity extends AppCompatActivity {
    private int ink, muted, blue, surface, soft, canvas, amber, buttonInk;
    private EditText nameInput;
    private ImageView photoView;
    private TextView initials;
    private Uri selectedPhoto;
    private ActivityResultLauncher<PickVisualMediaRequest> photoPicker;

    @Override protected void onCreate(Bundle state) {
        applyTheme();
        super.onCreate(state);
        photoPicker = registerForActivityResult(new ActivityResultContracts.PickVisualMedia(), uri -> {
            if (uri == null) return;
            try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch (SecurityException ignored) { /* Some picker providers grant a temporary read-only URI. */ }
            selectedPhoto = uri;
            renderPhoto(uri);
        });
        buildScreen();
    }

    private void applyTheme() {
        String mode = getSharedPreferences("spendwise", MODE_PRIVATE).getString("theme_mode", "system");
        int night = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        boolean dark = "dark".equals(mode) || ("system".equals(mode) && night == Configuration.UI_MODE_NIGHT_YES);
        canvas = dark ? Color.rgb(18,18,18) : Color.rgb(244,247,251);
        surface = dark ? Color.rgb(29,43,59) : Color.WHITE;
        soft = dark ? Color.rgb(39,67,96) : Color.rgb(224,236,248);
        ink = dark ? Color.rgb(243,246,250) : Color.rgb(22,37,54);
        muted = dark ? Color.rgb(190,202,216) : Color.rgb(83,101,122);
        blue = dark ? Color.rgb(31,69,105) : Color.rgb(36,88,136);
        amber = dark ? Color.rgb(255,190,65) : Color.rgb(242,177,56);
        buttonInk = Color.rgb(25,35,44);
    }

    private void buildScreen() {
        WindowCompat.enableEdgeToEdge(getWindow());
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(canvas);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(22), dp(16), dp(22), dp(28)); root.setBackgroundColor(canvas);
        scroll.addView(root);
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(dp(22), bars.top + dp(12), dp(22), bars.bottom + dp(24)); return insets;
        });
        setContentView(scroll);

        TextView back = text("‹   Profile", 20, ink, true); back.setContentDescription("Back"); root.addView(back); back.setOnClickListener(v -> finish());
        TextView subtitle = text("Make SpendWise feel like yours.", 14, muted, false); margin(subtitle, 6, 0); root.addView(subtitle);

        LinearLayout card = column(); card.setPadding(dp(20), dp(22), dp(20), dp(20)); card.setBackground(rounded(surface, 22)); margin(card, 22, 0); root.addView(card);
        FrameLayout photoFrame = new FrameLayout(this); photoFrame.setBackground(rounded(soft, 100)); photoFrame.setClipToOutline(true);
        initials = text("S", 30, blue, true); initials.setGravity(Gravity.CENTER); photoFrame.addView(initials, new FrameLayout.LayoutParams(-1,-1));
        photoView = new ImageView(this); photoView.setScaleType(ImageView.ScaleType.CENTER_CROP); photoView.setVisibility(View.GONE); photoFrame.addView(photoView, new FrameLayout.LayoutParams(-1,-1));
        LinearLayout.LayoutParams imageLp = new LinearLayout.LayoutParams(dp(112),dp(112)); imageLp.gravity = Gravity.CENTER_HORIZONTAL; card.addView(photoFrame,imageLp);
        Button choose = button("Choose a photo", false); margin(choose, 12, 0); card.addView(choose); choose.setOnClickListener(v -> photoPicker.launch(new PickVisualMediaRequest.Builder().setMediaType(ActivityResultContracts.PickVisualMedia.ImageOnly.INSTANCE).build()));
        Button remove = button("Remove photo", false); card.addView(remove); remove.setOnClickListener(v -> { selectedPhoto = null; renderPhoto(null); savePhoto(null, true); });

        TextView nameLabel = text("Display name", 14, ink, true); margin(nameLabel, 20, 5); card.addView(nameLabel);
        nameInput = new EditText(this); nameInput.setSingleLine(true); nameInput.setTextSize(16); nameInput.setTextColor(ink); nameInput.setHintTextColor(muted); nameInput.setHint("Your name (optional)");
        String savedName = effectiveName(); if (savedName != null) nameInput.setText(savedName);
        card.addView(nameInput, new LinearLayout.LayoutParams(-1, dp(52)));
        Button save = button("Save profile", true); margin(save, 14, 0); card.addView(save); save.setOnClickListener(v -> saveProfile());

        TextView privacyTitle = text("Your profile stays private", 15, ink, true); margin(privacyTitle, 18, 0); root.addView(privacyTitle);
        TextView privacy = text("Your display name and selected photo are saved in private app storage on this device and excluded from Android backup and device transfer. SpendWise does not upload or sync your custom profile. A name or photo from your signed-in provider may be shown as a default. Profile photos are chosen with Android’s photo picker, so broad storage access is not needed.", 13, muted, false);
        privacy.setLineSpacing(dp(3), 1f); margin(privacy, 6, 0); root.addView(privacy);

        String photoValue = currentPhoto(); if (photoValue != null) renderPhoto(Uri.parse(photoValue));
    }

    private String effectiveName() {
        android.content.SharedPreferences prefs = getSharedPreferences("spendwise_profile", MODE_PRIVATE);
        if (prefs.getBoolean("profile_name_customized", false)) return prefs.getString("profile_display_name", "");
        FirebaseUser user = currentUser(); return user == null ? "" : user.getDisplayName();
    }

    private String currentPhoto() {
        android.content.SharedPreferences prefs = getSharedPreferences("spendwise_profile", MODE_PRIVATE);
        if (prefs.contains("profile_photo_uri")) return prefs.getString("profile_photo_uri", null);
        if (prefs.getBoolean("profile_photo_cleared", false)) return null;
        FirebaseUser user = currentUser(); return user == null || user.getPhotoUrl() == null ? null : user.getPhotoUrl().toString();
    }

    private FirebaseUser currentUser() { return FirebaseApp.getApps(this).isEmpty() ? null : FirebaseAuth.getInstance().getCurrentUser(); }

    private void renderPhoto(Uri uri) {
        ProfilePhotoLoader.loadInto(photoView, uri, () -> { photoView.setVisibility(View.VISIBLE); initials.setVisibility(View.GONE); }, () -> {
            photoView.setVisibility(View.GONE); initials.setVisibility(View.VISIBLE);
            if (uri != null && selectedPhoto != null && uri.equals(selectedPhoto)) Toast.makeText(this, "That photo is no longer available. Please choose another.", Toast.LENGTH_LONG).show();
        });
    }

    private void saveProfile() {
        String name = nameInput.getText().toString().trim();
        if (name.length() > 60) { nameInput.setError("Use 60 characters or fewer"); return; }
        android.content.SharedPreferences.Editor editor = getSharedPreferences("spendwise_profile", MODE_PRIVATE).edit()
                .putBoolean("profile_name_customized", true).putString("profile_display_name", name);
        if (selectedPhoto != null) editor.putString("profile_photo_uri", selectedPhoto.toString()).putBoolean("profile_photo_cleared", false);
        editor.apply();
        Toast.makeText(this, "Profile saved on this device.", Toast.LENGTH_SHORT).show(); finish();
    }

    private void savePhoto(Uri uri, boolean cleared) {
        android.content.SharedPreferences.Editor editor = getSharedPreferences("spendwise_profile", MODE_PRIVATE).edit().putBoolean("profile_photo_cleared", cleared);
        if (uri == null) editor.remove("profile_photo_uri"); else editor.putString("profile_photo_uri", uri.toString());
        editor.apply();
    }

    private Button button(String value, boolean primary) { Button b = new Button(this); b.setText(value); b.setTextSize(14); b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setTextColor(primary ? buttonInk : ink); b.setBackground(rounded(primary ? amber : soft, 14)); return b; }
    private TextView text(String value, int size, int color, boolean bold) { TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); if (bold) t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private void margin(View view, int top, int bottom) { LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.topMargin = dp(top); lp.bottomMargin = dp(bottom); view.setLayoutParams(lp); }
    private GradientDrawable rounded(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + .5f); }
}
