package com.example.spendwise;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.widget.ImageView;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Loads picker URIs locally and provider avatar URLs without blocking the UI thread. */
final class ProfilePhotoLoader {
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private ProfilePhotoLoader() { }

    static void loadInto(ImageView image, Uri uri, Runnable loaded, Runnable unavailable) {
        image.setTag(uri == null ? null : uri.toString());
        image.setImageDrawable(null);
        if (uri == null) { unavailable.run(); return; }

        String scheme = uri.getScheme();
        if ("content".equals(scheme) || "file".equals(scheme)) {
            try {
                image.setImageURI(uri);
                if (image.getDrawable() == null) unavailable.run(); else loaded.run();
            } catch (RuntimeException error) { unavailable.run(); }
            return;
        }

        if (!"https".equalsIgnoreCase(scheme)) { unavailable.run(); return; }
        final String expected = uri.toString();
        IO.execute(() -> {
            Bitmap bitmap = null;
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(expected).openConnection();
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);
                connection.setInstanceFollowRedirects(true);
                connection.setRequestProperty("Accept", "image/*");
                if (connection.getContentLengthLong() > 5L * 1024L * 1024L) throw new IllegalStateException("Profile image too large");
                try (InputStream stream = connection.getInputStream()) { bitmap = BitmapFactory.decodeStream(stream); }
                if (bitmap != null && (bitmap.getWidth() > 512 || bitmap.getHeight() > 512)) {
                    float scale = Math.min(512f / bitmap.getWidth(), 512f / bitmap.getHeight());
                    Bitmap small = Bitmap.createScaledBitmap(bitmap, Math.round(bitmap.getWidth() * scale), Math.round(bitmap.getHeight() * scale), true);
                    if (small != bitmap) bitmap.recycle();
                    bitmap = small;
                }
            } catch (Exception ignored) {
                if (bitmap != null) bitmap.recycle();
                bitmap = null;
            } finally {
                if (connection != null) connection.disconnect();
            }
            final Bitmap result = bitmap;
            MAIN.post(() -> {
                if (!expected.equals(image.getTag())) { if (result != null) result.recycle(); return; }
                if (result == null) { unavailable.run(); return; }
                image.setImageBitmap(result);
                loaded.run();
            });
        });
    }
}
